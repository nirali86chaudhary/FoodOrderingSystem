import streamlit as st
import pandas as pd
import re
from datetime import datetime

st.set_page_config(page_title="Food Ordering System", layout="centered")
st.title("🍽️ Food Ordering System")

# -----------------------
# SESSION STATE
# -----------------------
if "order_confirmed" not in st.session_state:
    st.session_state.order_confirmed = False

if "customer_name" not in st.session_state:
    st.session_state.customer_name = ""

if "selected_table" not in st.session_state:
    st.session_state.selected_table = ""

# -----------------------
# THANK YOU PAGE
# -----------------------
if st.session_state.order_confirmed:
    st.balloons()
    st.success(f"🎉 Thank you, {st.session_state.customer_name}! Your order is confirmed.")
    st.write("We look forward to serving you again.")

    if st.button("🔄 Place Another Order"):
        st.session_state.order_confirmed = False
        st.session_state.selected_table = ""
        st.session_state.customer_name = ""
        st.rerun()

else:

    # -----------------------
    # SIDEBAR
    # -----------------------
    st.sidebar.header("🧑 Guest Details")
    customer_name = st.sidebar.text_input("Full Name *")
    contact_number = st.sidebar.text_input("Mobile Number *")

    st.sidebar.header("🧾 Order Settings")
    order_type = st.sidebar.radio(
        "Choose Order Type:",
        ["Parcel", "Eat at Restaurant"]
    )

    table_no = ""

    # -----------------------
    # TABLE DATA
    # -----------------------
    tables = [
        {"table": "T1", "seats": 2, "occupied": False},
        {"table": "T2", "seats": 2, "occupied": True},
        {"table": "T3", "seats": 3, "occupied": False},
        {"table": "T4", "seats": 3, "occupied": True},
        {"table": "T5", "seats": 4, "occupied": False},
        {"table": "T6", "seats": 4, "occupied": True},
        {"table": "T7", "seats": 5, "occupied": False},
        {"table": "T8", "seats": 5, "occupied": False},
        {"table": "T9", "seats": 6, "occupied": True},
        {"table": "T9", "seats": 6, "occupied": True},
    ]


    # -----------------------
    # EXACT TABLE MATCHING
    # -----------------------
    if order_type == "Eat at Restaurant":

        st.subheader("👥 Number of Guests")

        guests = st.number_input(
            "How many people?",
            min_value=1,
            max_value=20,
            step=1
        )

        st.subheader("🪑 Available Tables")

        matching_tables = [t for t in tables if t["seats"] == guests]

        if not matching_tables:
            st.error(f"❌ No {guests}-seater table available.")
        else:
            cols = st.columns(4)

            for i, t in enumerate(matching_tables):
                col = cols[i % 4]
                table_id = t["table"]
                label = f"{table_id} ({t['seats']} Seats)"

                if t["occupied"]:
                    col.markdown(
                        f"<div style='background:#ff4d4d;padding:10px;border-radius:8px;color:white;text-align:center;'>{label} ❌</div>",
                        unsafe_allow_html=True
                    )
                elif st.session_state.selected_table == table_id:
                    col.markdown(
                        f"<div style='background:#4da6ff;padding:10px;border-radius:8px;color:white;text-align:center;'>{label} ✅</div>",
                        unsafe_allow_html=True
                    )
                else:
                    if col.button(label, key=table_id):
                        st.session_state.selected_table = table_id
                        st.rerun()

            table_no = st.session_state.selected_table

    st.divider()

    # -----------------------
    # MENU DATA
    # -----------------------
    menus = {
        "🥗 Starters": {
            "Tomato Soup": 180,
            "Sweet Corn Soup": 170,
            "Hot & Sour Soup": 190,
            "Paneer Tikka": 260,
            "Veg Spring Rolls": 200,
            "Chilli Paneer": 260
        },
        "🍛 Main Course": {
            "Paneer Butter Masala": 380,
            "Dal Makhani": 350,
            "Veg Kolhapuri": 360,
            "Shahi Paneer": 390,
            "Veg Biryani": 420,
            "Jeera Rice": 220,
            "Butter Naan": 60,
            "Garlic Naan": 80
        },
        "🍕 Chef Specials": {
            "Margherita Pizza": 350,
            "Farmhouse Pizza": 420,
            "Veg Burger": 220,
            "Pasta Alfredo": 420
        },
        "🍰 Desserts": {
            "Gulab Jamun": 180,
            "Rasmalai": 220,
            "Chocolate Lava Cake": 260
        },
        "🥂 Beverages": {
            "Masala Chai": 90,
            "Espresso": 150,
            "Cold Coffee": 200,
            "Virgin Mojito": 220
        }
    }

    # -----------------------
    # MENU DISPLAY
    # -----------------------
    st.subheader("📜 Menu")

    order_items = []

    for category, items in menus.items():
        with st.expander(category):

            for item_name, price in items.items():

                selected = st.checkbox(
                    f"{item_name} (₹{price})",
                    key=f"check_{item_name}"
                )

                if selected:
                    qty = st.number_input(
                        f"Enter quantity for {item_name}",
                        min_value=1,
                        step=1,
                        key=f"qty_{item_name}"
                    )

                    order_items.append({
                        "Item": item_name,
                        "Price (₹)": price,
                        "Quantity": qty,
                        "Total (₹)": price * qty
                    })

      # -----------------------
    # BILL
    # -----------------------
    df = pd.DataFrame(order_items)

    # Start index from 1
    if not df.empty:
        df.index = range(1, len(df) + 1)

    subtotal = df["Total (₹)"].sum() if not df.empty else 0

    # Discount logic
    discount = 0
    offer_text = "No Offer Applied"
    if subtotal >= 499:
        discount = subtotal * 0.30
        offer_text = "30% OFF Applied"
    elif subtotal >= 399:
        discount = subtotal * 0.20
        offer_text = "20% OFF Applied"
    elif subtotal >= 299:
        discount = subtotal * 0.10
        offer_text = "10% OFF Applied"

    after_discount = subtotal - discount
    gst = after_discount * 0.05
    service_charge = after_discount * 0.02
    final_amount = after_discount + gst + service_charge               

    # -----------------------
    # Smart Coupon Display
    # -----------------------
    st.subheader("🎉 Available Offers")

    if subtotal < 299:
        st.info(f"🟡 Add ₹{299 - subtotal} more to get *10% OFF* 🎯")
    elif subtotal < 399:
        st.success("✅ *10% OFF Applied*")
        st.info(f"🟡 Add ₹{399 - subtotal} more to get *20% OFF* 🎯")
    elif subtotal < 499:
        st.success("✅ *20% OFF Applied*")
        st.info(f"🟡 Add ₹{499 - subtotal} more to get *30% OFF* 🎯")
    else:
        st.success("🎉 *30% OFF Applied — Maximum Discount!* 🥳")

    st.markdown("""
    *📌 Offer Rules*
    - Order ₹299 → 10% OFF  
    - Order ₹399 → 20% OFF  
    - Order ₹499 or more → 30% OFF  
    """)

    st.divider()               

    # -----------------------
    # BILL RECEIPT
    # -----------------------
    st.subheader("🧾 BILL RECEIPT")
    st.write(f"*Customer:* {customer_name}")
    st.write(f"*Mobile:* {contact_number}")
    st.write(f"*Order Type:* {order_type}")
    if order_type == "Eat at Restaurant" and table_no:
        st.write(f"*Table No:* {table_no}")
    st.markdown(f"🕒 {datetime.now().strftime('%d-%m-%Y %I:%M %p')}")
    if not df.empty:
        st.table(df)
    else:
        st.info("No items selected")

    st.markdown("---")
    st.write(f"*Subtotal:* ₹{subtotal}")
    st.write(f"*Discount ({offer_text}):* -₹{discount}")
    st.write(f"*GST (5%):* ₹{gst}")
    st.write(f"*Service Charge (2%):* ₹{service_charge}")
    st.success(f"### 💰 Final Payable Amount: ₹{final_amount}")

    st.markdown("---")

    # -----------------------
    # CSV BILL DOWNLOAD
    # -----------------------
    def generate_csv():
        summary = pd.DataFrame([
            {"Item": "Subtotal", "Total (₹)": subtotal},
            {"Item": f"Discount ({offer_text})", "Total (₹)": -discount},
            {"Item": "GST (5%)", "Total (₹)": gst},
            {"Item": "Service Charge (2%)", "Total (₹)": service_charge},
            {"Item": "Final Payable Amount", "Total (₹)": final_amount}
        ])
        csv_df = pd.concat([df, summary], ignore_index=True)
        return csv_df.to_csv(index=False).encode('utf-8')

    st.download_button(
        "📄 Download Bill as CSV",
        generate_csv(),
        file_name="food_bill.csv",
        mime="text/csv"
    )

    # -----------------------
    # CONFIRM ORDER
    # -----------------------
    if st.button("Confirm Order"):
        if order_type == "Eat at Restaurant" and not table_no:
            st.warning("⚠️ Please select a table")
        elif customer_name.strip() == "":
            st.warning("⚠️ Enter customer name")
        elif contact_number.strip() == "":
            st.warning("⚠️ Enter mobile number")
        elif subtotal == 0:
            st.warning("⚠️ Select at least one item")
        else:
            st.session_state.order_confirmed = True
            st.session_state.customer_name = customer_name
            st.rerun()
